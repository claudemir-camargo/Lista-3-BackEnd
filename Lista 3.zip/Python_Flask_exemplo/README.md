# Exemplo - Python/Flask

## Dicas:

* Instalar o Flask 
	* Sugestão: usar um ambiente python virtual (virtualenv)
	* Instalar o flask com o pip no virtualenv.
* rodar com:
	flask --app app run
	
* O serviço estará disponível no endereço http://localhost:5000
